/**
 * <p>Everything needed to make calls to the <strong>Simplify.com</strong> API
 * for <code>Card</code> objects.</p>
 */
package com.simplify.android.sdk.api.card;
